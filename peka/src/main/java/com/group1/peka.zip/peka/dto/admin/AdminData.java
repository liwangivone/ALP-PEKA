package com.group1.peka.dto.admin;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AdminData {

    private String userID;

    private String name;

    private String email;


    public AdminData(String userID, String name, String email) {
        this.userID = userID;
        this.name = name;
        this.email = email;
    } 
}
