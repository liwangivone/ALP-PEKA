package com.group1.peka.dto.user;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserData {

    private String userID;

    private String name;

    private String phoneNumber;

    private String email;

    private boolean isAdmin;


    public UserData(String email, String name, String phoneNumber, boolean isAdmin) {
        this.email = email;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.isAdmin = isAdmin;
    }   
}
