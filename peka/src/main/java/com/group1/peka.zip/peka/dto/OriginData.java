package com.group1.peka.dto;

public class OriginData {
    
}
