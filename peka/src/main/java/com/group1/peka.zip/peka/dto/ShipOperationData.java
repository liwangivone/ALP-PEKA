package com.group1.peka.dto;

public class ShipOperationData {
    
}
