package com.group1.peka.dto.destination;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DestinationData {

    private String destinationName;

    public DestinationData(String destinationName) {
        this.destinationName = destinationName;
    }
}
