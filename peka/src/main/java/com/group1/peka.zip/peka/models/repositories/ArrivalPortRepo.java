package com.group1.peka.models.repositories;

import com.group1.peka.models.entities.ArrivalPort;

import org.springframework.data.repository.CrudRepository;

public interface ArrivalPortRepo extends CrudRepository<ArrivalPort, String> {
    
}
