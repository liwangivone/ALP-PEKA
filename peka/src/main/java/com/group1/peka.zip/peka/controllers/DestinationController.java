package com.group1.peka.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.group1.peka.dto.ResponseData;
import com.group1.peka.dto.destination.DestinationListData;
import com.group1.peka.models.entities.Destination;
import com.group1.peka.services.DestinationService;

@RestController
@RequestMapping("/api/destination")
public class DestinationController {

    @Autowired
    private DestinationService destinationService;

    @PostMapping("/admin")
    public ResponseEntity<ResponseData<DestinationListData>> createDestination(
            @RequestParam String destinationName) {
        
        ResponseData<DestinationListData> responseData = new ResponseData<>();
        List<DestinationData> result = new ArrayList<>();

        Destination destinationCheck = destinationService.createDestination(destinationName);

        if (destinationCheck.isPresent()) {
            
        }
        }
    
}
